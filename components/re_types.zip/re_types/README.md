# re_types

EN: Declarations of common data types and structures required for other library modules
RU: Объявления общих типов данных и структур, необходимых для остальных модулей библиотеки

Author: Разживин Александр | Razzhivin Alexander
kotyara12@yandex.ru | https://kotyara12.ru | tg: @kotyara1971
